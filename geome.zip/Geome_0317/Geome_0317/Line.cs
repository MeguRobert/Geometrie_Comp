﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geome_0317
{
    class Line
    {
        public Point A;
        public Point B;
        public Line(Point A, Point B)
        {
            this.A = A;
            this.B = B;
        }
    }
}
