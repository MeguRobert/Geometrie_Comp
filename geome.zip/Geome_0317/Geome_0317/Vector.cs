﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geome_0317
{
    class Vector
    {
        public Point startPoint;
        public Point endPoint;
        public Vector(Point startPoint, Point endPoint)
        {
            this.startPoint = startPoint;
            this.endPoint = endPoint;
        }



    }
}
